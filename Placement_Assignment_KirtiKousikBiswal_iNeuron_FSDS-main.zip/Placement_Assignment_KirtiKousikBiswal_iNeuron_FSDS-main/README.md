# Placement_Assignment_KirtiKousikBiswal_iNeuron_FSDS
Placement Assignments for the FSDS 2.0 course of iNeuron
